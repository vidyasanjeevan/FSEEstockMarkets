﻿using MediatR;
using StockAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockAPI.StockFeatures.Commands
{
    public class CreateStockCommand : IRequest<StockDetails>
    {
        public StockDetails StockDetails { get; set; }

        public CreateStockCommand(StockDetails stockDetails)
        {
            this.StockDetails = stockDetails;
        }
    }
}
