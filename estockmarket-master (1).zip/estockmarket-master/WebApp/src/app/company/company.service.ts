import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import {StockDetails} from '../shared/models/stock'
import { CompanyRegistration } from '../shared/models/companyregister';
import { Observable } from 'rxjs';
import {ConfigService} from 'src/app/shared/config.service';
@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  constructor(private http: HttpClient, private configService:ConfigService) { }


  getAllCompanyDetails() {

    return this.http.get(this.configService.baseUrl + '/company/getall');
  }

  getCompanyDetailsByCompanyCode(companyCode?: string) {


    return this.http.get(this.configService.baseUrl + '/company/getcompanybycode/' + companyCode);
      
  }

  searchCompanyDetailsByCompanyCode(companyCode?: string) {


    return this.http.get(this.configService.baseUrl + '/company/searchcompany/' + companyCode);
      
  }
  createCompany(compRegistration: CompanyRegistration) {

console.log(compRegistration);
    return this.http.post<CompanyRegistration>(this.configService.baseUrl + '/company/createcompany', compRegistration);

      
  }


  getStockDetails( companyCode: string, startDate: string, endDate: string) {

console.log(companyCode+' startdate:' + startDate +' enddate :'+ endDate);
    return this.http.get(this.configService.baseUrl+ '/stock/get/' + companyCode + '/' + startDate + '/' + endDate)
      
  }

  addStockDetails( stock: StockDetails) {

   // const httpOptions = this.getHttpOptions(token);

    return this.http.post(this.configService.baseUrl + '/stock/createstock' ,  stock)
     
     
  }

  delete(companyCode: string) {

    return this.http.delete(this.configService.baseUrl + `/company/deletecompany/${companyCode}`)

  }

  

}
