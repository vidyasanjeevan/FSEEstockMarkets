﻿using CompanyAPI.CompanyFeatures.Commands;
using CompanyAPI.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CompanyAPI.CompanyFeatures.Handlers
{
    public class UpdateCompanyHandler : IRequestHandler<UpdateCompanyCommand, bool>
    {
        private readonly CompanyServices _companyService;
        public UpdateCompanyHandler(CompanyServices companyService)
        {
            _companyService = companyService;
        }
        public async Task<bool> Handle(UpdateCompanyCommand request, CancellationToken cancellationToken)
        {
            return await  _companyService.UpdateCompany(request.CompanyCode, request.Company);
        }
    }
}
