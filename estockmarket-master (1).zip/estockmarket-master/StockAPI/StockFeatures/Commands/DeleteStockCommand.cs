﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockAPI.StockFeatures.Commands
{
    public class DeleteStockCommand:  IRequest<bool>
    {
        public string CompanyCode { get; set; }

        public DeleteStockCommand(string companyCode)
        {
            this.CompanyCode = companyCode;
        }
    }
}
