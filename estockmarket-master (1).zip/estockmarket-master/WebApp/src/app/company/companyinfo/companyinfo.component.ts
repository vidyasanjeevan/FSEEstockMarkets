import { Component, OnInit,Input } from '@angular/core';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { finalize } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';
import { StockDetails} from 'src/app/shared/models/stock';
import {CompanyService} from '../company.service';
import { NavigationEnd, Router } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-companyinfo',
  templateUrl: './companyinfo.component.html',
  styleUrls: ['./companyinfo.component.css']
})
export class CompanyinfoComponent implements OnInit {

  @Input() companyInfo: any;
  error: string = '';
  isListView: boolean = true;
  startdtModel: NgbDateStruct | any;
  enddtModel: NgbDateStruct | any;

  startDate: Date | undefined;
  endDate: Date | undefined;
  public dateFormat: string = "yyyy-mm-dd";

  min: number = 0;
  max: number = 0;
  average: number = 0;

  stockDetails: StockDetails = { companyCode: '', stockPrice: 0.00, createdDate: '' };
  stockPriceDetails: any = [];
  navigationSubscription;



  constructor(
    private router: Router,
    private datePipe: DatePipe,
    private _Activatedroute:ActivatedRoute,
    private companyService: CompanyService

  ) {  
    this.navigationSubscription = this.router.events.subscribe((e: any) => {
      if (e instanceof NavigationEnd) {
        this.setStockValues();
      }
    });

  }

  onStartDateSelect(evt: any) {
    this.startDate = new Date(evt.year, evt.month - 1, evt.day);
  }

  onEndDateSelect(evt: any) {
    this.endDate = new Date(evt.year, evt.month - 1, evt.day);
  }


  ngOnInit(): void {
  }





  setStockValues() {
    this.startdtModel = null;
    this.enddtModel = null;
    this.stockPriceDetails = [];
    this.min = 0;
    this.max = 0;
    this.average = 0;
    this.stockDetails = { companyCode: '', stockPrice: 0.00, createdDate: '' };
  }

  getStockDetails() {
    let startDate = this.datePipe.transform(this.startDate, 'yyyy-MM-dd') as string;
    let endDate = this.datePipe.transform(this.endDate, 'yyyy-MM-dd') as string;

    this.companyService.getStockDetails(this.companyInfo.companyCode, startDate, endDate)
      .pipe(finalize(() => {
      })).subscribe(
        (result: any) => {
          console.log(result);
          this.stockPriceDetails = result.stockDetails;
          this.min = result.minVal;
          this.max = result.maxVal;
          this.average = result.average;
        });
  }

  }




