﻿using CompanyAPI.Models;
using CompanyAPI.Queries;
using CompanyAPI.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CompanyAPI.Handlers
{
    public class GetAllCompanyDetailsHandler : IRequestHandler<GetAllCompanyDetailsQuery, IList<CompanyDetails>>
    {
        private readonly CompanyServices _companyService;
        public GetAllCompanyDetailsHandler(CompanyServices companyService)
        {
            _companyService = companyService;
        }
        public async Task<IList<CompanyDetails>> Handle(GetAllCompanyDetailsQuery request, CancellationToken cancellationToken)
        {
            var companies = _companyService.GetAllCompanyDetailsAsync();

            return await companies;
        }
    }
}
