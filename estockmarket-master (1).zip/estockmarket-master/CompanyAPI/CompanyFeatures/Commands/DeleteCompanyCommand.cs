﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyAPI.CompanyFeatures.Commands
{
    public class DeleteCompanyCommand : IRequest<bool>
    {

        public string CompanyCode { get; set; }

        public DeleteCompanyCommand(string companyCode)
        {
            this.CompanyCode = companyCode;
        }
    }
}
