﻿using LoginAPI.Commands;
using LoginAPI.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace LoginAPI.Handlers
{
    public class UpdateUserHandler : IRequestHandler<UpdateUserCommand, bool>
    {
        private readonly UserServices _userService;
        public UpdateUserHandler(UserServices userService)
        {
            _userService = userService;
        }
        public Task<bool> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
        {
            return _userService.UpdateUser(request.UserId,request.Users);
        }
    }
}
