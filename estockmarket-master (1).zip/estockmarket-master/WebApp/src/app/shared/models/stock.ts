export class StockDetails {
 
    constructor(
        public companyCode:string,
        public stockPrice:number,
        public createdDate:string
    ) { 
        
    }


   

}
