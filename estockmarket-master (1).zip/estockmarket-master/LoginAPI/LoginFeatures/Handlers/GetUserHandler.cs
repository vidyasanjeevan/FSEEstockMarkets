﻿using LoginAPI.Models;
using LoginAPI.Queries;
using LoginAPI.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace LoginAPI.Handlers
{
    public class GetUserHandler : IRequestHandler<GetUserQuery, UserDetails>
    {
        private readonly UserServices _userService;
        public GetUserHandler(UserServices userService)
        {
            _userService = userService;
        }
        public Task<UserDetails> Handle(GetUserQuery request, CancellationToken cancellationToken)
        {
            return _userService.GetUserAsync(request.UserId);
        }
    }
}
