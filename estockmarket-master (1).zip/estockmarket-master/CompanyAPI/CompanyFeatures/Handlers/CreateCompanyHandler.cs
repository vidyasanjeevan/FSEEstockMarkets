﻿using CompanyAPI.Commands;
using CompanyAPI.Models;
using CompanyAPI.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CompanyAPI.Handlers
{
    public class CreateCompanyHandler : IRequestHandler<CreateCompanyCommand, CompanyDetails>
    {
        private readonly CompanyServices _companyService;
        public CreateCompanyHandler(CompanyServices companyService)
        {
            _companyService = companyService;
        }
        public Task<CompanyDetails> Handle(CreateCompanyCommand request, CancellationToken cancellationToken)
        {
            return _companyService.CreateCompanyAsync(request.CompanyDetails);
        }
    }
}
