﻿using CompanyAPI.CompanyFeatures.Queries;
using CompanyAPI.Models;
using CompanyAPI.Queries;
using CompanyAPI.Services;
using MediatR;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CompanyAPI.CompanyFeatures.Handlers
{
    public class SearchCompanyDetailsHandler : IRequestHandler<SearchCompanyDetailsQuery, IList<CompanyDetails>>
    {
        private readonly CompanyServices _companyService;
        public SearchCompanyDetailsHandler(CompanyServices companyService)
        {
            _companyService = companyService;
        }

        public async Task<IList<CompanyDetails>> Handle(SearchCompanyDetailsQuery request, CancellationToken cancellationToken)
        {
            var companies = _companyService.SearchCompanyDetailsAsync(request.CompanyCode);

            return await companies;
        }
    }
}