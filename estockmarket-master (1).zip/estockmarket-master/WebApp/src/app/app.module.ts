import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { RegistrationComponent } from './user/registration/registration.component';
import { LoginComponent } from './user/login/login.component';
import { CompanyComponent } from './company/company.component';
import { NavbarComponent } from './layout/navbar/navbar.component';
import { RegistercompanyComponent } from './company/registercompany/registercompany.component';
//import { ViewstockComponent } from './company/viewstock/viewstock.component';
import { CompanyinfoComponent } from './company/companyinfo/companyinfo.component';
import { CompanygridComponent } from './company/companygrid/companygrid.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { CompanyStockComponent } from './company/company-stock/company-stock.component';
import { AddstockComponent } from './company/addstock/addstock.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { TokenInterceptor } from './../app/auth/token.interceptor';
import { NgxSpinnerModule } from "ngx-spinner";
@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    RegistrationComponent,
    LoginComponent,
    CompanyComponent,
    NavbarComponent,
    RegistercompanyComponent,
    //ViewstockComponent,
    CompanyinfoComponent,
    CompanygridComponent,
    CompanyStockComponent,
    AddstockComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    NgbModule,
    NgxSpinnerModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true,
   
    },  [DatePipe] 
  ],
  bootstrap: [AppComponent]
})
export class AppModule { 


  
}
