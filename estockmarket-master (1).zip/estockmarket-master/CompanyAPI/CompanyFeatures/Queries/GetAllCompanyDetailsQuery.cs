﻿using CompanyAPI.Models;
using MediatR;
using System.Collections.Generic;


namespace CompanyAPI.Queries
{
    public class GetAllCompanyDetailsQuery : IRequest<IList<CompanyDetails>>
    {
        public GetAllCompanyDetailsQuery()
        {

        }
    }
}
