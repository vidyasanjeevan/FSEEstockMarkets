﻿using CompanyAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyAPI.Services
{
   public interface ICompanyServices
    {
        Task<List<CompanyDetails>> GetAllCompanyDetailsAsync();

        Task <CompanyDetails> GetCompanyDetailsByCodeAsync(string companyCode);
        Task<List<CompanyDetails>> SearchCompanyDetailsAsync(string companyCode);

        Task<CompanyDetails> CreateCompanyAsync(CompanyDetails company);

        //Task<CompanyDetails> UpdateCompanyDetailsAsync(string companyId, CompanyDetails company);

        //bool DeleteCompanyDetailsAsync(string companyId);
    }
}
