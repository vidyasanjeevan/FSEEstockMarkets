﻿using CompanyAPI.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyAPI.CompanyFeatures.Queries
{
    public class SearchCompanyDetailsQuery : IRequest<IList<CompanyDetails>>
    {
        public string CompanyCode { get; set; }

        public SearchCompanyDetailsQuery(string companyCode)
        {
            this.CompanyCode = companyCode;
        }
    }
}
