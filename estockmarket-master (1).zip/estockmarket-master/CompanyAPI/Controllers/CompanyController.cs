﻿using AutoMapper;
using CompanyAPI.Commands;
using CompanyAPI.CompanyFeatures.Commands;
using CompanyAPI.CompanyFeatures.Queries;
using CompanyAPI.Models;
using CompanyAPI.Queries;
using CompanyAPI.Services;
using MassTransit;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace CompanyAPI.Controllers
{
    [ApiController]
    [Route("api/market/[controller]")]

    public class CompanyController : ControllerBase
    {

        private readonly IMediator mediator;
        private readonly IBus _bus;
        private readonly ILogger<CompanyController> _logger;

        public CompanyController(IMediator mediator, IBus bus, ILogger<CompanyController> logger)
        {
            this.mediator = mediator;
            _bus = bus;
            _logger = logger;
        }
        [HttpGet]
        [Route("getall")]
        public async Task<IActionResult> GetAllCompanyDetails()
        {

            try
            {
                _logger.LogInformation("called GetAllCompanyDetailsQuery");
                var companyDetails = mediator.Send(new GetAllCompanyDetailsQuery());
                _logger.LogInformation(" GetAllCompanyDetailsQuery details fetched");
                return StatusCode((int)HttpStatusCode.OK, await companyDetails);
            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.NotFound);
            }
        }

        [HttpGet]
        [Route("getcompanybycode/{companyCode}", Name = "getcompanybycode")]
        public async Task<IActionResult> GetCompanyDetailsByCode(string companyCode)
        {
            try
            {
                _logger.LogInformation("called GetCompanyDetailsByCodeQuery");
                var companyDetails = mediator.Send(new GetCompanyDetailsByCodeQuery(companyCode));
                _logger.LogInformation(" GetCompanyDetailsByCodeQuery details fetched");
                return StatusCode((int)HttpStatusCode.OK, await companyDetails);
            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.NotFound);
            }
        }

        [HttpGet]
        [Route("searchcompany/{companyCode}", Name = "searchcompany")]
        public async Task<IActionResult> SearchCompanyByCode(string companyCode)
        {
            try
            {
                _logger.LogInformation("inside search company");
                var companyDetails = mediator.Send(new SearchCompanyDetailsQuery(companyCode));
                _logger.LogInformation(" search company completed");
                return StatusCode((int)HttpStatusCode.OK, await companyDetails);
   
            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.NotFound);
            }
        }

        [HttpPost]
        [Route("createcompany")]
        public async Task<IActionResult> CreateCompany([FromBody] CompanyDetails companyDetails)
        {
            try
            {

            if(companyDetails==null)
                {
                    return BadRequest();
                }
                var existingcompanyDetails = mediator.Send(new GetCompanyDetailsByCodeQuery(companyDetails.CompanyCode));

               

                if (companyDetails.CompanyTurnover<100000000)
                {
                    _logger.LogInformation("Company Turnover must be greater than 10Cr");
                    ModelState.AddModelError("turnover", "Company Turnover must be greater than 10Cr");
                    return StatusCode((int)HttpStatusCode.BadRequest, "Company Turnover must be greater than 10Cr");
                }

                else if (existingcompanyDetails.Result==null)
                {
                    _logger.LogInformation("inside create company");
                    var company = await mediator.Send(new CreateCompanyCommand(companyDetails));
                    return StatusCode((int)HttpStatusCode.OK, company);
                }


                else
                {
                    _logger.LogInformation("Company Code already exists");
                    ModelState.AddModelError("code", "Company Code already exists");
                    return StatusCode((int)HttpStatusCode.BadRequest, "Company Code already exists");
                }
          

              



            }
            catch (Exception )
            {
                return StatusCode((int)HttpStatusCode.BadRequest);
            }
        }

        [HttpDelete]
        [Route("deletecompany/{companyCode}", Name = "deletecompany")]
        public async Task <IActionResult> DeleteCompany(string companyCode)
        {
            try
            {
                var companyDetails = mediator.Send(new GetCompanyDetailsByCodeQuery(companyCode));
                if (companyDetails == null)
                {
                    ModelState.AddModelError("Delete", $"CompanyCode {companyCode} does not exist");
                    return BadRequest(ModelState);

                }

                //var isDeleted = mediator.Send(new DeleteCompanyCommand(companyCode));
                //return StatusCode((int)HttpStatusCode.OK, isDeleted);

                else
                {
                    Company company = new Company();
                    company.CompanyCode = companyCode;
                    Uri uri = new Uri("rabbitmq://localhost/ticketQueue");
                    var endPoint = await _bus.GetSendEndpoint(uri);
                    await endPoint.Send(company);

                    //delete company details
                    var isDeleted = mediator.Send(new DeleteCompanyCommand(companyCode));
                   return StatusCode((int)HttpStatusCode.OK, isDeleted);
              
                }







            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.BadRequest);
            }
        }


        [HttpPut]
        [Route("Put/{companyCode}")]
        public IActionResult UpdateCompany([FromBody] CompanyDetails company, string companyCode)
        {
            try
            {
                var isUpdated = mediator.Send(new UpdateCompanyCommand(companyCode, company));
                return StatusCode((int)HttpStatusCode.OK, isUpdated);
            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.BadRequest);
            }
        }


    }
}

