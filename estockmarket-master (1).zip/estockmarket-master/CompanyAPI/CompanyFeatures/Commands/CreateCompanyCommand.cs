﻿using CompanyAPI.Models;
using MediatR;

namespace CompanyAPI.Commands
{
    public class CreateCompanyCommand : IRequest<CompanyDetails>
    {

        public CompanyDetails CompanyDetails { get; set; }
        public CreateCompanyCommand(CompanyDetails company)
        {
            this.CompanyDetails = company;
        }
    }
}
