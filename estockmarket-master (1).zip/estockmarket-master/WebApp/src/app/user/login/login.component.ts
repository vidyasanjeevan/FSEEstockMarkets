import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import {UserService} from 'src/app/user/user.service';
import { UserDetails } from 'src/app/shared/models/user';
import { NavbarService } from 'src/app/layout/navbar/navbar.service';
import { NotificationService } from 'src/app/notification.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: UserDetails = {
    userId: '', userName: '', password: '', emailId: ''
  };

  constructor(private router: Router,private userservice: UserService,public nav: NavbarService ,private toastr: NotificationService) { }

  ngOnInit(): void {
    this.nav.hide();
  }


  onSubmit(event: Event) {
    event.preventDefault();

      this.userservice.login(this.user).subscribe(
        (res: any) => {
          localStorage.setItem('token', res.token);
       
          this.router.navigateByUrl('/company');
        },
        (err:any) => {
          if (err.status == 400)
          console.log(err);
            this.toastr.showError('Incorrect username or password.', 'Authentication failed.');
        
        }
      );
    }





}
