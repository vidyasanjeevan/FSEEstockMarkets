﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginAPI.Commands
{
    public class DeleteUserCommand: IRequest<bool>
    {
        public string UserId { get; set; }

        public DeleteUserCommand(string userId)
        {
            this.UserId = userId;
        }
    }
}
