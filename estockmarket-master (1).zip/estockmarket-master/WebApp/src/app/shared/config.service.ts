import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {

  constructor() { }

  get baseUrl() {
  //return 'https://estockmarketsgateway.azurewebsites.net/';
   return 'http://localhost:61406/';
  }


}
