import { Component, OnInit,EventEmitter, Output,Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {CompanyService} from 'src/app/company/company.service';
import { CompanyRegistration } from 'src/app/shared/models/companyregister';
import {StockDetails} from 'src/app/shared/models/stock'
import { ActivatedRoute, Router } from '@angular/router';
import { finalize } from 'rxjs/operators';
import { NotificationService } from 'src/app/notification.service';

@Component({
  selector: 'app-addstock',
  templateUrl: './addstock.component.html',
  styleUrls: ['./addstock.component.css']
})
export class AddstockComponent implements OnInit {
@Input ('companyCode') 
set data(data: any) {
 this.stockDetails.companyCode=data;
}
  @Output() cancelClick:EventEmitter<boolean>=new EventEmitter<boolean>();
  companies: CompanyRegistration[] ;
  stockDetails: StockDetails = {
  companyCode: '', stockPrice: 0.00, createdDate: ''
  
  };
  companyCode:string='';
  constructor(   

    private httpClient:HttpClient,
    private companyService: CompanyService,
    private router: Router,
    private toastr: NotificationService
     ) {

      this.companies = [];

     }
   
  ngOnInit(): void {
 
  }

  
  onSubmit(event: Event) {
    event.preventDefault();
    this.stockDetails.createdDate = new Date().toISOString();

    this.companyService.addStockDetails(this.stockDetails)
      .pipe(finalize(() => {
      }))
      .subscribe(
        (result: any) => {
          if (result) {
            console.log(result);
            this.toastr.showSuccess("Stock details added successfully", "Add Stocks");
          //  this.success = true;
            this.resetForm();
            console.log(result);
            //this.companyAdded.emit();
          }
        },
        (error: string) => {
         // this.error = error;
        });
  }  

cancel()
{
this.cancelClick.emit(true);
}


private resetForm() {
  this.stockDetails.companyCode = '';
  this.stockDetails.stockPrice = 0;

}

}