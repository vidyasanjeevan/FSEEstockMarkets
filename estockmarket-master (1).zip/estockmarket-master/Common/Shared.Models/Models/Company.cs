﻿using System;

namespace Shared.Models
{
    public class Company
    {
       
        public string CompanyCode { get; set; }
        public string CompanyName { get; set; }
    }
}
