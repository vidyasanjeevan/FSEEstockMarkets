import { Component, OnInit,Input } from '@angular/core';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { finalize } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';
import { StockDetails} from 'src/app/shared/models/stock';
import {CompanyService} from '../company.service';
import { NavigationEnd, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { NavbarService } from 'src/app/layout/navbar/navbar.service';
import { NotificationService } from 'src/app/notification.service';
@Component({
  selector: 'app-company-stock',
  templateUrl: './company-stock.component.html',
  styleUrls: ['./company-stock.component.css']
})
export class CompanyStockComponent implements OnInit {
  companyName:any;
  turnover:any;
  exchange:any;
  companyCode:any;
  IsAddStock :boolean=false;
  error: string = '';
  isStock: boolean = true;
  startdtModel: NgbDateStruct | any;
  enddtModel: NgbDateStruct | any;
  isCancel:boolean=false;
  startDate: Date | undefined;
  endDate: Date | undefined;
  public dateFormat: string = "yyyy-mm-dd";

  min: number = 0;
  max: number = 0;
  average: number = 0;

  stockDetails: StockDetails = { companyCode: '', stockPrice: 0.00, createdDate: '' };
  stockPriceDetails: any = [];
  navigationSubscription;

  constructor(
    private router: Router,
    private datePipe: DatePipe,
    private _Activatedroute:ActivatedRoute,
    private companyService: CompanyService,
    public nav: NavbarService ,
    private toastr: NotificationService
    

  ) {  
    this.navigationSubscription = this.router.events.subscribe((e: any) => {
      if (e instanceof NavigationEnd) {
        this.nav.show();
        this.setStockValues();
   
      }
    });

this.companyName= this._Activatedroute.snapshot.paramMap.get('companyName');
this.turnover=this._Activatedroute.snapshot.paramMap.get('companyTurnover');
this.exchange=this._Activatedroute.snapshot.paramMap.get('companyTurnover');
this.companyCode=this._Activatedroute.snapshot.paramMap.get('companyCode');

  }

  onStartDateSelect(evt: any) {
    this.startDate = new Date(evt.year, evt.month - 1, evt.day);
  }

  onEndDateSelect(evt: any) {
    this.endDate = new Date(evt.year, evt.month - 1, evt.day);
  }


  ngOnInit(): void {
  }





  setStockValues() {
    this.startdtModel = null;
    this.enddtModel = null;
    this.stockPriceDetails = [];
    this.min = 0;
    this.max = 0;
    this.average = 0;
    this.stockDetails = { companyCode: '', stockPrice: 0.00, createdDate: '' };
  }

  getStockDetails() {
    let startDate = this.datePipe.transform(this.startDate, 'yyyy-MM-dd') as string;
    let endDate = this.datePipe.transform(this.endDate, 'yyyy-MM-dd') as string;

    this.companyService.getStockDetails(this.companyCode, startDate, endDate)
      .pipe(finalize(() => {
      })).subscribe(
        (result: any) => {
          console.log(result);
          this.stockPriceDetails = result.stockDetails;
          this.min = result.minVal;
          this.max = result.maxVal;
          this.average = result.average;
        });
  }


  addStockDetails()
  {
    this.isStock=false;
    this.IsAddStock=true;
  }

  cancelEventHandler(isCancel:boolean){
    if(isCancel)
     this.isStock=true;
     this.IsAddStock=false;
   }

   delete() {
    this.companyService.delete( this.companyCode)
      .pipe(finalize(() => {
      }))
      .subscribe(
        (result: any) => {
          if (result) {
            this.toastr.showSuccess("Company Deleted Successfully", "Delete Company");
this.router.navigateByUrl('/company');

          }
        },
        (error: string) => {
          this.toastr.showError('An error occured while deleting company. Please try again later.', {
            classname: 'bg-danger text-light',
            autohide: true,
            delay: 2000
          });
          this.error = error;
        });
  }

}
