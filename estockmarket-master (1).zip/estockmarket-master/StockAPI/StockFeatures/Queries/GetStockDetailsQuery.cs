﻿using MediatR;
using StockAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockAPI.StockFeatures.Queries
{
    public class GetStockDetailsQuery : IRequest<IEnumerable<StockDetails>>
    {
        public string CompanyCode { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public GetStockDetailsQuery(string companyCode, DateTime startDate, DateTime endDate)
        {
            this.CompanyCode = companyCode;
            this.StartDate = startDate;
            this.EndDate = endDate;
        }
    }
}
