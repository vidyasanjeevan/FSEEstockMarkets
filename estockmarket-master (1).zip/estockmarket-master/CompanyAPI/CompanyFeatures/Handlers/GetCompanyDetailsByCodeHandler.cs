﻿using CompanyAPI.Models;
using CompanyAPI.Queries;
using CompanyAPI.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CompanyAPI.Handlers
{
    public class GetCompanyDetailsByCodeHandler : IRequestHandler<GetCompanyDetailsByCodeQuery,CompanyDetails>
    {
        private readonly CompanyServices _companyService;
        public GetCompanyDetailsByCodeHandler(CompanyServices companyService)
        {
            _companyService = companyService;
        }

        public  Task<CompanyDetails> Handle(GetCompanyDetailsByCodeQuery request, CancellationToken cancellationToken)
        {
            var company= _companyService.GetCompanyDetailsByCodeAsync(request.CompanyCode);
            return  company;
        }

    }
}
