﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using StockAPI.Configurations;
using StockAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockAPI.Services
{
    public class StockService
    {
        private readonly IMongoCollection<StockDetails> _stock;
        private readonly DeveloperDatabaseConfiguration _settings;
        public StockService(IOptions<DeveloperDatabaseConfiguration> settings)
        {
            _settings = settings.Value;
            var client = new MongoClient(_settings.ConnectionString);
            var database = client.GetDatabase(_settings.DatabaseName);
            _stock = database.GetCollection<StockDetails>(_settings.StockCollectionName);
        }
        //public async Task<StockDetails> CreateStocks(StockDetails stockDetails)
        //{
        //    stockDetails.CreatedDate = DateTime.Now;
        //   await _stock.InsertOneAsync(stockDetails);
        //    return stockDetails;
        //}
        public Task CreateStock(StockDetails stockDetails)
        {
            return _stock.InsertOneAsync(stockDetails);
        }

        public IEnumerable<StockDetails> GetStockDetails(string companyCode, DateTime startDate, DateTime endDate)
        {

            var endDateExclusive = endDate.AddDays(1);
            return _stock.Find(c => c.CompanyCode == companyCode && c.CreatedDate >= startDate && c.CreatedDate <= endDateExclusive).ToList();
          
        }

        public async Task<bool> DeleteStocksByCompanyCode(string companyCode)
        {

            _stock.DeleteMany(c=> c.CompanyCode== companyCode);

            return true;
        }
    }
}
