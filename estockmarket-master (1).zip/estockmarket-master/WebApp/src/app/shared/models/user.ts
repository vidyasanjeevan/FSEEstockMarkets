export class UserDetails {
 
    constructor(
        public userId:string,
        public userName:string,
        public password:string,
        public emailId:string
    ) { 
        
    }


   

}
