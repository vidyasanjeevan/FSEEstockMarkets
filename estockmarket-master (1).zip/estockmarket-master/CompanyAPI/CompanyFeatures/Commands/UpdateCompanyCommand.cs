﻿using CompanyAPI.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyAPI.CompanyFeatures.Commands
{
    public class UpdateCompanyCommand : IRequest<bool>
    {
        public string CompanyCode { get; set; }
        public CompanyDetails Company { get; set; }

        public UpdateCompanyCommand(string companyCode, CompanyDetails company)
        {
            this.CompanyCode = companyCode;
            this.Company = company;
        }
    }
}
