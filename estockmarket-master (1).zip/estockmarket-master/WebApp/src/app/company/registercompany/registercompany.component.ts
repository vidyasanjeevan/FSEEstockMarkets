import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { finalize } from 'rxjs/operators';
import { CompanyRegistration} from 'src/app/shared/models/companyregister';
import {CompanyService} from 'src/app/company/company.service';
import { getLocaleDateTimeFormat } from '@angular/common';
import { NavbarService } from 'src/app/layout/navbar/navbar.service';
import { NotificationService } from 'src/app/notification.service';

@Component({
  selector: 'app-registercompany',
  templateUrl: './registercompany.component.html',
  styleUrls: ['./registercompany.component.css']
})
export class RegistercompanyComponent implements OnInit {
  success: boolean = false;
  error:any |null;

  compRegistration: CompanyRegistration = {
    companyCode: '', companyName: '', companyCeo: '', companyTurnover: 0, companyWebsite: '', stockExchange: ''
  };

  submitted: boolean = false;

  @Output() companyAdded: EventEmitter<any> = new EventEmitter<any>();

  constructor(private companyService: CompanyService,public nav: NavbarService, private router: Router, private toastr: NotificationService ) { }

  ngOnInit(): void {
    this.nav.show();
  }


  onSubmit(event: Event) {
    event.preventDefault();
   


    this.error="";
    this.companyService.createCompany(this.compRegistration)
      .pipe(finalize(() => {
      }))
      .subscribe(
        (result: any) => {
          if (result) {
            this.success = true;
this.toastr.showSuccess("Company registered Successfully", "Register Company");
            this.resetForm();

            this.router.navigate(['/company']);
          }
        },
        (error: any) => {
          this.error = error.error;
          
        });
      
      }  

 private isValid(company:CompanyRegistration)
 {
  this.error="";
if(company.companyTurnover<100000000)
{
this.error="Company Turnover must be greater than 10 Cr";
return false;
}
this.companyService.getCompanyDetailsByCompanyCode(company.companyCode)
      .pipe(finalize(() => {
      })).subscribe(
        (result:any) => {
         if(result !=null)
         {
          this.error="Company Code already exists";
          return false;

         }
else{
  return true;
}
        },
        (error:any) => {

        });

 }

  private resetForm() {
    this.compRegistration.companyCode = '';
    this.compRegistration.companyName = '';
    this.compRegistration.companyCeo = '';
    this.compRegistration.companyTurnover = 0;
    this.compRegistration.companyWebsite = '';
    this.compRegistration.stockExchange = '';
  }





}
