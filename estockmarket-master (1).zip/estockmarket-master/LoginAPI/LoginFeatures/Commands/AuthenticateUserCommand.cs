﻿using LoginAPI.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginAPI.LoginFeatures.Commands
{
    public class AuthenticateUserCommand : IRequest<bool>
    {
        public string Password { get; set; }
        public UserDetails Users { get; set; }

        public AuthenticateUserCommand(string password, UserDetails users)
        {
            this.Password = password;
            this.Users = users;
        }
    }
}
