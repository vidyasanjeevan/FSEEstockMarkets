﻿using CompanyAPI.Configurations;
using CompanyAPI.Models;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyAPI.Services
{
    public class CompanyServices :ICompanyServices
    {
        private readonly IMongoCollection<CompanyDetails> _company;
        private readonly DeveloperDatabaseConfiguration _settings;
        public CompanyServices(IOptions<DeveloperDatabaseConfiguration> settings)
        {
            _settings = settings.Value;
            var client = new MongoClient(_settings.ConnectionString);
            var database = client.GetDatabase(_settings.DatabaseName);
            _company = database.GetCollection<CompanyDetails>(_settings.CompanyCollectionName);
        }
        public async Task<List<CompanyDetails>> GetAllCompanyDetailsAsync()
        {
            return await _company.Find(c => true).ToListAsync();
        }
        public  Task<CompanyDetails> GetCompanyDetailsByCodeAsync(string companyCode)
        {
            return  _company.Find(c => c.CompanyCode == companyCode).FirstOrDefaultAsync();
        }

        public async Task<List<CompanyDetails>> SearchCompanyDetailsAsync(string companyCode)
        {
            return await _company.Find(c => c.CompanyCode == companyCode).ToListAsync();
        }
        public async Task<CompanyDetails> CreateCompanyAsync(CompanyDetails company)
        {
            company.CreatedDate = DateTime.Now;
            await _company.InsertOneAsync(company);
            return company;
        }
        public async Task<bool> DeleteCompany(string companyCode)
        {
            var company = GetCompanyDetailsByCodeAsync(companyCode);

            if (company == null) return default;
            _company.DeleteOne(u => u.CompanyCode == companyCode);
            return true;

        }

        public async Task<bool> UpdateCompany(string companyCode, CompanyDetails company)
        {
            _company.ReplaceOne(c => c.CompanyCode == companyCode, company);
            return true;

        }


    }

}

