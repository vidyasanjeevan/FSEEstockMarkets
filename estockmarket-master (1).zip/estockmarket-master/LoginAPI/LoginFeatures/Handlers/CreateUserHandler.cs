﻿using LoginAPI.Commands;
using LoginAPI.Models;
using LoginAPI.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace LoginAPI.Handlers
{
    public class CreateUserHandler : IRequestHandler<CreateUserCommand, UserDetails>
    {
        private readonly UserServices _userService;
        public CreateUserHandler(UserServices userService)
        {
            _userService = userService;
        }
        public Task<UserDetails> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {
            return _userService.CreateUserAsync(request.UserDetails);
        }
    }
}
