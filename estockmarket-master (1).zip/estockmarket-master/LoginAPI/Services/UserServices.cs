﻿using LoginAPI.Configurations;
using LoginAPI.Models;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginAPI.Services
{
    public class UserServices : IUserServices
    {
        private readonly IMongoCollection<UserDetails> _user;
        private readonly DeveloperDatabaseConfiguration _settings;
        public UserServices(IOptions<DeveloperDatabaseConfiguration> settings)
        {
            _settings = settings.Value;
            var client = new MongoClient(_settings.ConnectionString);
            var database = client.GetDatabase(_settings.DatabaseName);
            _user = database.GetCollection<UserDetails>(_settings.UserCollectionName);
        }

        //Authenticate User based on userid
        public async Task<UserDetails> GetUserAsync(string userId)
        {
            return await _user.Find<UserDetails>(c => c.UserId == userId).FirstOrDefaultAsync();
        }
     
        public async Task<UserDetails> CreateUserAsync(UserDetails user)
        {
            user.CreatedDate = DateTime.Now;
            await _user.InsertOneAsync(user);
            return user;
        }

        public  async Task<bool> DeleteUser(string userId)
        {
            var user = GetUserAsync(userId);
           
            if (user == null) return default;
             _user.DeleteOne(u => u.UserId == userId);
            return true;

        }

        public async Task< bool> UpdateUser(string userId, UserDetails user)
        {
            _user.ReplaceOne(c => c.UserId == userId, user);
            return true;

        }


        public async Task<bool> CheckPasswordAsync(string password, UserDetails userDetails)
        {
            var userObj = GetUserAsync(userDetails.UserId);

           var user= await _user.Find<UserDetails>(c => c.UserId == userDetails.UserId && c.Password== password).FirstOrDefaultAsync();

            if (user!=null)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

    }
}
