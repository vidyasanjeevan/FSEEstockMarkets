﻿using LoginAPI.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginAPI.Commands
{
    public class UpdateUserCommand :IRequest<bool>
    {
        public string UserId { get; set; }
        public UserDetails Users { get; set; }

        public UpdateUserCommand(string userId, UserDetails users)
        {
            this.UserId = userId;
            this.Users = users;
        }
    }
}
