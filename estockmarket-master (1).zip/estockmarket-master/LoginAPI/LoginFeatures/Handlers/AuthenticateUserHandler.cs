﻿using LoginAPI.LoginFeatures.Commands;
using LoginAPI.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace LoginAPI.LoginFeatures.Handlers
{
    public class AuthenticateUserHandler : IRequestHandler<AuthenticateUserCommand, bool>
    {
        private readonly UserServices _userService;

        public AuthenticateUserHandler(UserServices userService)
        {
            _userService = userService;
        }
        public Task<bool> Handle(AuthenticateUserCommand request, CancellationToken cancellationToken)
        {
            return _userService.CheckPasswordAsync(request.Password, request.Users);
        }
    }
}
