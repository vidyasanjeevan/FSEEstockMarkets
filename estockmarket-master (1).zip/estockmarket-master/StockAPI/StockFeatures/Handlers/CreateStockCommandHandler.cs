﻿using MediatR;
using StockAPI.Models;
using StockAPI.Services;
using StockAPI.StockFeatures.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace StockAPI.StockFeatures.Handlers
{
    //public class CreateStockCommandHandler : IRequestHandler<CreateStockCommand, StockDetails>
    //{
    //    private readonly StockService _stockService;
    //    public CreateStockCommandHandler(StockService stockService)
    //    {
    //        _stockService = stockService;
    //    }

    //    //public Task<StockDetails> Handle(CreateStockCommand request, CancellationToken cancellationToken)
    //    //{
    //    //    //return _stockService.CreateStocks(request.StockDetails);
    //    //}
    //}
}
