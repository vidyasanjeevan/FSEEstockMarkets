﻿using LoginAPI.Commands;
using LoginAPI.Services;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace LoginAPI.Handlers
{
    public class DeleteUserHandler : IRequestHandler<DeleteUserCommand,bool>
    {
        private readonly UserServices _userService;
        public DeleteUserHandler(UserServices userService)
        {
            _userService = userService;
        }

        public async Task<bool> Handle(DeleteUserCommand request, CancellationToken cancellationToken)
        {
          return await _userService.DeleteUser(request.UserId);

           
           
        }

      
    }
}
