import { Component, OnInit } from '@angular/core';
import { Router,NavigationEnd  } from '@angular/router';
import { NavbarService } from './navbar.service';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
isLoggedIn:boolean =false;
  constructor(private router:Router,public nav: NavbarService) { 

  }

  ngOnInit(): void {

    if (localStorage.getItem('token')!=null)
    {
      this.isLoggedIn=true;
    }

  }



  onLogout() {
    localStorage.removeItem('token');
    this.isLoggedIn=false;
    this.router.navigate(['/user/login']);
  }

}
