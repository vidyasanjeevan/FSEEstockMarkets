import { DecimalPipe } from '@angular/common';

export class CompanyRegistration {
 
    constructor(
        public companyCode:  string,
        public companyName: string,
        public companyCeo: string,
        public companyTurnover: number,
        public companyWebsite: string,
        public stockExchange: string
    ) { 
        
    }


   

}
