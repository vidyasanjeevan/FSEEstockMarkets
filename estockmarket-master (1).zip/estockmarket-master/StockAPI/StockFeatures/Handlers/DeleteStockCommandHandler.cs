﻿using MediatR;
using StockAPI.Services;
using StockAPI.StockFeatures.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace StockAPI.StockFeatures.Handlers
{
    public class DeleteStockCommandHandler : IRequestHandler<DeleteStockCommand, bool>
    {
        private readonly StockService _stockService;
        public DeleteStockCommandHandler(StockService stockService)
        {
            _stockService = stockService;
        }

        public async Task<bool> Handle(DeleteStockCommand request, CancellationToken cancellationToken)
        {
      
         return await _stockService.DeleteStocksByCompanyCode(request.CompanyCode);
        }
    }
}
