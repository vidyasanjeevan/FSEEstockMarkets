﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyAPI.Models
{
    public class CompanyDetails
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("CompanyCode")]
        public string CompanyCode { get; set; }

        [BsonElement("CompanyName")]
        public string CompanyName { get; set; }

        [BsonElement("CompanyCeo")]
        public string CompanyCeo { get; set; }

        [BsonElement("CompanyTurnover")]
        public decimal CompanyTurnover { get; set; }


        [BsonElement("CompanyWebsite")]
        public string CompanyWebsite { get; set; }

        [BsonElement("StockExchange")]
        public string StockExchange { get; set; }

        [BsonElement("CreatedDate")]
        public DateTime CreatedDate { get; set; }

        [BsonElement("ModifiedDate")]
        public DateTime ModifiedDate { get; set; }

    }
}
