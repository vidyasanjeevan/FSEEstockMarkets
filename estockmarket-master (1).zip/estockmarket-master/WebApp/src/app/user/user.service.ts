import { Injectable } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { UserDetails } from 'src/app/shared/models/user';
import {ConfigService} from 'src/app/shared/config.service';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private fb: FormBuilder, private http: HttpClient,private configService:ConfigService) { }


  login(user: UserDetails) {
    return this.http.post(this.configService.baseUrl + '/user/login', user);
  }

}
