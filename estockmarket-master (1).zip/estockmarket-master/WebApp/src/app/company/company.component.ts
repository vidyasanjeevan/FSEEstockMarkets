import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { finalize } from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import {CompanyService} from './company.service';
import { CompanyRegistration } from '../shared/models/companyregister';
import { NavbarService } from 'src/app/layout/navbar/navbar.service';
import { NgxSpinnerService } from "ngx-spinner";
import { NullTemplateVisitor } from '@angular/compiler';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
   companyDetails: CompanyRegistration[] ;
   companyInfo: any = null;
   companySelected:any=null;
   companies: any = null;
   companyCode:string='';

  success: boolean = false;
  error: string = '';
  companyListVisible :boolean=true;
  companyInfoVisible:boolean=false;

  constructor(
    private httpClient:HttpClient,
    private companyService: CompanyService,
    private router: Router,
    public nav: NavbarService,
    private spinner: NgxSpinnerService
  ) 
  {
    this.companyDetails = [];
this.nav.show();
   }

  ngOnInit(): void {
    this.getAllCompanyDetails();
  }

  public getAllCompanyDetails(){
    this.spinner.show();
    this.companyService.getAllCompanyDetails()
    .pipe(finalize(() => {
      this.spinner.hide();
    })).subscribe(
      (result:any) => {
        this.companyListVisible=true;
        this.companyInfoVisible=false;
        this.companyDetails =result;
        this.companies = result;
      },
      (error:any) => {
        alert(error)
      });
  }

  


  public getCompanyDetailsByCompanyCode(companyCode: string) {
    if (!companyCode) {

      this.companyService.getCompanyDetailsByCompanyCode(companyCode)
      .pipe(finalize(() => {
      })).subscribe(
        (result:any) => {
          console.log(result);
          this.companyDetails =result;

        },
        (error:any) => {
          alert(error)
        });
  

    }
  }


    public searchCompanyByCompanyCode(companyCode: string) {
      if (companyCode =='') {
        this.getAllCompanyDetails();
      }
      else
      {
        this.companyService.searchCompanyDetailsByCompanyCode(companyCode)
        .pipe(finalize(() => {
        })).subscribe(
          (result:any) => {
            this.companyListVisible=true;
            this.companyInfoVisible=false;
            this.companyDetails =result;
  
          },
          (error:any) => {
            alert(error)
          });
    
  }
      }









    public onCompanySelected(code: string) {
      if (!code) {
        this.companyInfoVisible = false;
        this.companyListVisible = true;
       // this.companyRegVisible = false;
        this.companyInfo = null;
      }
      else {
        this.companyService.getCompanyDetailsByCompanyCode(code)
          .pipe(finalize(() => {
          })).subscribe(
            result => {
              this.companyInfo = result;
              console.log('first'+this.companyInfo);
              this.companyInfoVisible = true;
              this.companyListVisible = false;
              //this.companyRegVisible = false;
  
              this.router.navigate(['/companyinfo']);
              
            },
            (error) => {
              alert(error)
            });
      }
    }
  
    
   

}
