﻿using CompanyAPI.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyAPI.Queries
{
    public class GetCompanyDetailsByCodeQuery : IRequest<CompanyDetails>
    {
        public string CompanyCode { get; set; }

        public GetCompanyDetailsByCodeQuery(string companyCode)
        {
            this.CompanyCode = companyCode;
        }
    }
}
