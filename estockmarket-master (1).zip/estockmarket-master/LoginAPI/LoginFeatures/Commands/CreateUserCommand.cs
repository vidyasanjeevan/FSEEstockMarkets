﻿using LoginAPI.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginAPI.Commands
{
    public class CreateUserCommand : IRequest<UserDetails>
    {

        public UserDetails UserDetails { get; set; }
        public CreateUserCommand(UserDetails user)
        {
            this.UserDetails = user;
        }

    }
}
