﻿using MassTransit;
using MediatR;
using Shared.Models;
using StockAPI.StockFeatures.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace StockAPI.Consumer
{
    public class Consumer : IConsumer<Company>
    {
        private readonly IMediator mediator;

          public Consumer(IMediator mediator)
                {
            this.mediator = mediator;
                }
        public async Task Consume(ConsumeContext<Company> context )
        {
         
            string companyCode = Convert.ToString(context.Message.CompanyCode);

            //delete stock details 


            var stock = mediator.Send(new DeleteStockCommand(companyCode));
            await mediator.Send(stock);

        }

      
    }
}
