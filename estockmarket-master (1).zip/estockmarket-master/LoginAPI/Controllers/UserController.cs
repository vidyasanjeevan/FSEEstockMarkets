﻿using LoginAPI.Commands;
using LoginAPI.LoginFeatures.Commands;
using LoginAPI.Models;
using LoginAPI.Queries;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace LoginAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IMediator mediator;
        private readonly ApplicationSettings _appSettings;

        public UserController(IMediator mediator, IOptions<ApplicationSettings> appSettings)
        {
            this.mediator = mediator;
            _appSettings = appSettings.Value;
        }


        [HttpGet]
        [Route("Get/{userId}")]
        public async Task<IActionResult> GetUser(string userId)
        {
            try
            {
                var userDetails = mediator.Send(new GetUserQuery(userId));
                return StatusCode((int)HttpStatusCode.OK, await userDetails);
            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.NotFound);
            }
        }

        [HttpPost]
        [Route("Create")]
        public async Task<IActionResult> CreateUser([FromBody] UserDetails userDetails)
        {
            try
            {
                var user = mediator.Send(new CreateUserCommand(userDetails));
                return StatusCode((int)HttpStatusCode.Created, await user);
            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.BadRequest);
            }
        }

        [HttpDelete]
        [Route("Delete/{userId}")]
        public IActionResult DeleteUser(string userId)
        {
            try
            {
                var isDeleted = mediator.Send(new DeleteUserCommand(userId));
                return StatusCode((int)HttpStatusCode.OK, isDeleted);
            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.BadRequest);
            }
        }


        [HttpPut]
        [Route("Put/{userId}")]
        public IActionResult UpdateUser([FromBody] UserDetails user, string userId)
        {
            try
            {
                var isUpdated = mediator.Send(new UpdateUserCommand(userId, user));
                return StatusCode((int)HttpStatusCode.OK, isUpdated);
            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.BadRequest);
            }
        }


        [HttpPost]
        [Route("login")]
        //POST : /api/ApplicationUser/Login
        public async Task<IActionResult> Login([FromBody] UserDetails model)
        {
            // var user = await _userManager.FindByNameAsync(model.UserName);
            //if (user != null && await _userManager.CheckPasswordAsync(user, model.Password))
            //{


            var isValidUser = mediator.Send(new AuthenticateUserCommand(model.Password,model));
            

            if (isValidUser.Result)
            {
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                Subject = new ClaimsIdentity(new Claim[]
                {
                        new Claim("UserID",model.UserId.ToString())
                }),
                Expires = DateTime.UtcNow.AddDays(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_appSettings.JWT_Secret)), SecurityAlgorithms.HmacSha256Signature)
                };
            var tokenHandler = new JwtSecurityTokenHandler();
            var securityToken = tokenHandler.CreateToken(tokenDescriptor);
            var token = tokenHandler.WriteToken(securityToken);
            return  Ok(new  {  token });

             }
               else
            {
                return BadRequest(new { message = "Username or password is incorrect." });
            }
              
            }


        [HttpGet]
        [Authorize]
        [Route("getuserprofile")]
        public async Task<IActionResult> GetUserProfile()
        {
            string userId = User.Claims.First(c => c.Type == "UserID").Value;
            try
            {
                var userDetails = mediator.Send(new GetUserQuery(userId));
                return StatusCode((int)HttpStatusCode.OK, await userDetails);
            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.NotFound);
            }
        }




    }
    }

