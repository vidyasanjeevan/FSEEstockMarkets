﻿using LoginAPI.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginAPI.Queries
{
    public class GetUserQuery : IRequest<UserDetails>
    {
        public string UserId { get; set; }

        public GetUserQuery(string userId)
        {
            this.UserId = userId;
        }
    }
}
