﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using StockAPI.Models;
using StockAPI.Services;
using StockAPI.StockFeatures.Commands;
using StockAPI.StockFeatures.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace StockAPI.Controllers
{
    [ApiController]
    [Route("api/market/[controller]")]
    public class StockController : ControllerBase
    {
        private readonly IMediator mediator;
        private readonly StockService stockService;
        public StockController(IMediator mediator,StockService stockService)
        {
            this.mediator = mediator;
            this.stockService = stockService;
        }


        [HttpGet]
        [Route("get/{companyCode}/{startDate}/{endDate}")]
        public  IActionResult GetStockDetails(string companyCode,string startDate, string endDate)
        {

            try
            {
                var startDateFormatted = DateTime.Parse(startDate);
                var endDateFormatted = DateTime.Parse(endDate);
           
                var stockDetails = mediator.Send(new GetStockDetailsQuery(companyCode, startDateFormatted, endDateFormatted)).Result;

                var stockSummaryModel = new StockSummaryDetails();
                if (stockDetails.Any())
                {
                    stockSummaryModel.StockDetails = stockDetails;
                    stockSummaryModel.MinVal = stockDetails.Min(s => s.StockPrice);
                    stockSummaryModel.MaxVal = stockDetails.Max(s => s.StockPrice);
                    stockSummaryModel.Average = (stockDetails.Aggregate<StockDetails, double>(0, (total, s) => total + s.StockPrice))/(stockDetails.Count());
                }
                else
                {
                    stockSummaryModel.StockDetails = new List<StockDetails>();
                }

                return Ok(stockSummaryModel);



            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.NotFound);
            }
        }


        [HttpPost]
        [Route("createstock")]
        public async Task<ActionResult<bool>> CreateStock([FromBody] StockDetails stockDetails)
        {
            try
            {
               
                stockDetails.CreatedDate = DateTime.Now;

                //var stock = mediator.Send(new CreateStockCommand(stockDetails));
                //return StatusCode((int)HttpStatusCode.Created, stock);

                await stockService.CreateStock(stockDetails);
                return Ok(true);
            }
            catch (Exception)
            {
                return StatusCode((int)HttpStatusCode.BadRequest);
            }
        }

    }
}
