import { Component, Input, Output, EventEmitter,OnInit   } from '@angular/core';
import { CompanyRegistration } from 'src/app/shared/models/companyregister';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-companygrid',
  templateUrl: './companygrid.component.html',
  styleUrls: ['./companygrid.component.css']
})
export class CompanygridComponent implements OnInit {

@Input () companyDetails :CompanyRegistration[] ;


  constructor() {
    this.companyDetails = [];

   }

  ngOnInit(): void {
  }

  public getCompanyStockInfo(companyInfo:CompanyRegistration)
  {

console.log(companyInfo);

  }

  viewStockDetails() {
 
  }


}
