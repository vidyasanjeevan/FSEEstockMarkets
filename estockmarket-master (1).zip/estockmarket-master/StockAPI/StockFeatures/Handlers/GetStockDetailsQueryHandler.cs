﻿using MediatR;
using StockAPI.Models;
using StockAPI.Services;
using StockAPI.StockFeatures.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace StockAPI.StockFeatures.Handlers
{
    public class GetStockDetailsQueryHandler : IRequestHandler<GetStockDetailsQuery, IEnumerable<StockDetails>>
    {
        private readonly StockService _stockService;
        public GetStockDetailsQueryHandler(StockService stockService)
        {
            _stockService = stockService;
        }

        async Task<IEnumerable<StockDetails>> IRequestHandler<GetStockDetailsQuery, IEnumerable<StockDetails>>.Handle(GetStockDetailsQuery request, CancellationToken cancellationToken)
        {
            return _stockService.GetStockDetails(request.CompanyCode, request.StartDate, request.EndDate);
        }
    }
}
