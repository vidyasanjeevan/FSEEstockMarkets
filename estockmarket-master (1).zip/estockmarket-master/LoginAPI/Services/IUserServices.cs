﻿using LoginAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginAPI.Services
{
  public  interface IUserServices
    {
        Task<UserDetails> GetUserAsync(string userId);

        Task<UserDetails> CreateUserAsync(UserDetails user);

        Task<bool> UpdateUser(string userId, UserDetails user);

        Task<bool> DeleteUser(string companyId);
    }
}
